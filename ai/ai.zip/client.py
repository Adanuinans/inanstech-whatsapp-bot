# ai/client.py
import re
import random
import math
from datetime import datetime
from mistralai.client import MistralClient
from mistralai.models.chat_completion import ChatMessage
from config import MISTRAL_API_KEY

class AIClient:
    def __init__(self):
        print("🤖 AI Client initialized")
        
        # Initialize Mistral AI
        self.mistral_available = False
        
        # Debug: Show that we have the key
        print(f"📡 Mistral API Key present: {MISTRAL_API_KEY[:10]}...")
        
        if MISTRAL_API_KEY and len(MISTRAL_API_KEY) > 10:
            try:
                # Initialize the Mistral client
                self.client = MistralClient(api_key=MISTRAL_API_KEY)
                self.model = "mistral-small-latest"  # Free tier model
                self.mistral_available = True
                print("  ✅ Mistral AI initialized successfully!")
                print("  📊 Free tier: 500,000 tokens/min")
            except Exception as e:
                print(f"  ⚠️ Mistral initialization error: {e}")
                self.mistral_available = False
        else:
            print("  ⚠️ No valid Mistral API key found")
        
        if self.mistral_available:
            print("✅ AI Client ready - Using Mistral AI as primary")
        else:
            print("✅ AI Client ready - Using rule-based system")
    
    def generate_reply(self, message):
        """Generate intelligent response using Mistral AI"""
        
        # Try Mistral AI first
        if self.mistral_available:
            try:
                print("🎯 Generating with Mistral AI...")
                response = self.generate_mistral(message)
                if response and len(response) > 5:
                    print("✅ Mistral AI response received!")
                    return response
                else:
                    print("⚠️ No valid response from Mistral, using fallback")
            except Exception as e:
                print(f"⚠️ Mistral error: {e}")
        
        # Fallback to rule-based
        print("🎯 Using rule-based fallback")
        return self.rule_based_response(message)
    
    def generate_mistral(self, message):
        """Generate response using Mistral AI"""
        try:
            system_prompt = """You are a friendly, helpful AI assistant for Inanstech, a Nigerian technology company.

COMPANY SERVICES:
- Website Design & Development: Starting from N100,000 (basic), N250,000 (e-commerce)
- Mobile App Development: Starting from N500,000 (Android & iOS)
- Custom Software Development: Custom quotes based on requirements
- Digital Marketing: From N150,000/month (SEO, social media, ads)
- E-commerce Solutions: Custom online stores with payment integration
- Branding & Design: Logo, identity design packages

YOUR PERSONALITY:
- Be friendly, warm, and professional
- Keep responses concise (2-4 sentences)
- Always be helpful and solution-oriented
- If asked about pricing, mention the starting prices above
- If asked about contact, share info@inanstech.com.ng and +234 123 456 7890

RULES:
- Answer ANY question naturally
- For random questions, respond helpfully then connect to business
- Be conversational and engaging
- For business questions, be enthusiastic and helpful"""
            
            # Make the API call using the legacy client format
            response = self.client.chat(
                model=self.model,
                messages=[
                    ChatMessage(role="system", content=system_prompt),
                    ChatMessage(role="user", content=message)
                ],
                temperature=0.7,
                max_tokens=200
            )
            
            # Extract the response
            reply = response.choices[0].message.content.strip()
            if reply:
                print(f"🤖 Mistral: {reply[:100]}...")
                return reply
            return None
            
        except Exception as e:
            print(f"Mistral generation error: {e}")
            return None
    
    def rule_based_response(self, message):
        """Enhanced rule-based fallback - comprehensive and reliable"""
        msg = message.lower()
        original_msg = message
        msg = re.sub(r'[^\w\s\.\,\!\?\-\'\%\*\+\/\\]', '', msg)
        
        # ========== GEOGRAPHY & NIGERIA ==========
        
        if "capital of nigeria" in msg or "nigeria capital" in msg:
            responses = [
                "The capital of Nigeria is Abuja! It became the capital in 1991, replacing Lagos. Abuja is located in the Federal Capital Territory (FCT) and is known for Aso Rock. At Inanstech, we can help you build location-based apps or tourism websites!",
                "Abuja is Nigeria's capital city! It was purpose-built as the capital and is centrally located. Looking to build a travel app or location-based service? Inanstech can help!",
                "Nigeria's capital is Abuja, located in the heart of the country. At Inanstech, we build websites and apps for tourism and location-based services. What project do you have in mind?"
            ]
            return random.choice(responses)
        
        elif "abuja" in msg:
            responses = [
                "Abuja is the capital city of Nigeria! Located in the Federal Capital Territory (FCT), it's known for Aso Rock, the National Mosque, and beautiful architecture. At Inanstech, we can help you build location-based apps or tourism websites!",
                "Abuja is Nigeria's capital, situated in the central region. It was purpose-built as the capital in 1991. Need help building a travel app? Inanstech can help!",
                "Abuja is located in the heart of Nigeria, in the Federal Capital Territory. Looking to build a travel app or location-based service? Let's talk!"
            ]
            return random.choice(responses)
        
        elif "lagos" in msg:
            responses = [
                "Lagos is Nigeria's largest city and former capital! Located in southwestern Nigeria, it's the country's economic hub. At Inanstech, we help businesses in Lagos with websites, apps, and digital marketing!",
                "Lagos is a coastal city in southwestern Nigeria, known for its vibrant culture and business opportunities. Need a website or app for your Lagos business? Inanstech can help!",
                "Lagos is Nigeria's commercial capital along the Atlantic coast. Looking to expand your business online in Lagos? Let's build something great!"
            ]
            return random.choice(responses)
        
        # ========== MATH CALCULATIONS ==========
        
        # Basic arithmetic
        if re.search(r'\d+\s*[+\-*/]\s*\d+', msg):
            calc_match = re.search(r'(\d+)\s*([+\-*/])\s*(\d+)', msg)
            if calc_match:
                a = int(calc_match.group(1))
                op = calc_match.group(2)
                b = int(calc_match.group(3))
                
                if op == '+':
                    result = a + b
                    return f"{a} + {b} = {result}\n\nNeed more calculations? We can build custom calculators for your business!"
                elif op == '-':
                    result = a - b
                    return f"{a} - {b} = {result}\n\nWant to automate calculations? We can build tools to make math easier!"
                elif op == '*':
                    result = a * b
                    return f"{a} × {b} = {result}\n\nWe can build calculators, invoicing tools, or any math-based software you need!"
                elif op == '/':
                    if b != 0:
                        result = a / b
                        return f"{a} ÷ {b} = {result:.2f}\n\nNeed more calculations? Let's build something to handle all your math needs!"
        
        # Square root
        elif "square root" in msg:
            numbers = re.findall(r'\d+', msg)
            if numbers:
                num = int(numbers[0])
                result = math.sqrt(num)
                if result.is_integer():
                    return f"The square root of {num} is {int(result)}! {int(result)} x {int(result)} = {num}\n\nWe can help build math education apps or calculators!"
                else:
                    return f"The square root of {num} is approximately {result:.2f}\n\nWe can build custom calculators or math learning tools!"
        
        # ========== BUSINESS SERVICES ==========
        
        elif any(word in msg for word in ["pricing", "price", "cost", "how much", "quote"]):
            return """Our packages:
• Basic Website: N100,000
• E-commerce Site: N250,000
• Mobile App: from N500,000
• Custom Software: tailored quote
• Digital Marketing: from N150,000/month

Want a custom quote? Tell me what you need!"""
        
        elif any(word in msg for word in ["contact", "phone", "email", "whatsapp"]):
            return """Reach us anytime!
Email: info@inanstech.com.ng
Phone/WhatsApp: +234 123 456 7890
Monday-Friday, 9AM-6PM"""
        
        elif any(word in msg for word in ["portfolio", "work", "examples"]):
            return "Check out our portfolio at https://www.inanstech.com.ng/portfolio. We've worked with 50+ happy clients!"
        
        # ========== SERVICES ==========
        
        elif any(word in msg for word in ["website", "web", "design"]):
            return "We create modern, responsive websites starting from N100,000. What type of website are you looking for? Business site, e-commerce, or blog?"
        
        elif any(word in msg for word in ["app", "mobile", "android", "ios"]):
            return "We develop high-quality mobile apps for both Android and iOS starting from N500,000. Tell me about your app idea!"
        
        elif any(word in msg for word in ["software", "system", "custom"]):
            return "We build custom software solutions for businesses. Tell me about your requirements and I'll help you get started!"
        
        elif any(word in msg for word in ["marketing", "seo", "social media"]):
            return "Our digital marketing packages start from N150,000/month and include SEO, social media management, and targeted ads."
        
        # ========== CONVERSATIONAL ==========
        
        elif any(word in msg for word in ["hello", "hi", "hey", "good morning"]):
            greetings = [
                "Hello! I'm your Inanstech AI assistant - ready to help with websites, apps, and digital marketing! What can I do for you?",
                "Hi there! Welcome! I can help with web design, mobile apps, and digital marketing. What's on your mind?",
                "Hey! Ready to build something amazing? I'm here to help with tech solutions!"
            ]
            return random.choice(greetings)
        
        elif any(word in msg for word in ["how are you", "how's it going"]):
            return "I'm doing great, thanks for asking! Ready to help with your tech needs. What can I do for you today?"
        
        elif any(word in msg for word in ["thank", "thanks"]):
            thanks = [
                "You're very welcome! Anything else I can help with?",
                "My pleasure! Happy to help. Let me know if you have more questions!",
                "Glad I could help! Remember, Inanstech is here when you need websites, apps, or business solutions!"
            ]
            return random.choice(thanks)
        
        elif any(word in msg for word in ["bye", "goodbye", "see you"]):
            return "Take care! Remember, Inanstech is here when you need websites, apps, or business solutions. Have a wonderful day!"
        
        elif "joke" in msg:
            jokes = [
                "Why do programmers prefer dark mode? Because light attracts bugs! What can we build for you?",
                "What do you call a developer from Nigeria? A Nai-Java programmer! Want to learn coding or need an app built?",
                "Why did the website go to therapy? It had too many issues! We can help fix that - what do you need built?",
                "Why was the JavaScript developer sad? Because he didn't know how to 'null' his feelings! What can we build for you?"
            ]
            return random.choice(jokes)
        
        elif any(word in msg for word in ["menu", "help", "services", "what do you do"]):
            return """I can help with:

📚 Answer questions about Nigeria, Abuja, Lagos
🧮 Calculate math problems
💻 Teach programming and tech concepts
🚀 Build websites, apps, and software
📈 Digital marketing services
🎨 Branding and design

What would you like to explore? Type a specific question!"""
        
        # ========== DEFAULT ==========
        else:
            if "?" in original_msg:
                responses = [
                    "Great question! At Inanstech, we build websites (from N100k) and apps (from N500k). Could you tell me more about what you're looking for?",
                    "Interesting question! Inanstech specializes in turning ideas into digital reality. What project do you have in mind?",
                    "Great question! I'd love to help. What specific tech solution are you interested in? Websites, apps, or digital marketing?"
                ]
                return random.choice(responses)
            else:
                responses = [
                    "Thanks for reaching out! I'm here to help with website design (from N100,000), mobile apps (from N500,000), and digital marketing. What can I help you create?",
                    "Great to hear from you! How can I assist today? Type 'menu' to see what I can do.",
                    "I'm listening! Let me know what you need - I can teach, build, or just chat. What's on your mind?",
                    "Ready to help! Whether you want to learn, build, or grow - I've got you covered. Tell me what you're interested in!"
                ]
                return random.choice(responses)