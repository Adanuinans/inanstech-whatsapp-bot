import time
import re
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import (
    StaleElementReferenceException,
    TimeoutException
)


def watch_messages(driver, router, state):
    print("=" * 50)
    print("WHATSAPP MESSAGE WATCHER STARTED")
    print("=" * 50)

    print("Waiting for WhatsApp to load...")
    time.sleep(10)
    print("WhatsApp loaded. Monitoring for messages...")

    processed_messages = set()

    while True:
        try:
            unread_rows = get_unread_chat_rows(driver)

            if not unread_rows:
                time.sleep(2)
                continue

            print(f"\n📬 Found {len(unread_rows)} unread chat(s)")

            for i in range(len(unread_rows)):
                try:
                    # Re-fetch to avoid stale elements
                    unread_rows = get_unread_chat_rows(driver)
                    if i >= len(unread_rows):
                        break

                    row = unread_rows[i]
                    chat_name = get_chat_name_from_row(row) or "Unknown"
                    unread_count = get_unread_count_from_row(row)

                    print(f"\n{'='*60}")
                    print(f"💬 Processing {chat_name} - {unread_count} new message(s)")
                    print(f"{'='*60}")

                    if not open_chat_row(driver, row):
                        print(f"Could not open chat: {chat_name}")
                        continue

                    opened_chat = get_current_chat_name(driver) or chat_name
                    print(f"Opened chat: {opened_chat}")

                    read_and_reply_messages(
                        driver,
                        router,
                        state,
                        opened_chat,
                        unread_count,
                        processed_messages
                    )

                    time.sleep(1.5)

                except StaleElementReferenceException:
                    print("Stale unread row, retrying next...")
                    continue
                except Exception as e:
                    print(f"Error processing unread row: {e}")
                    continue

            time.sleep(2)

        except Exception as e:
            print(f"Watcher error: {e}")
            time.sleep(4)


def get_unread_chat_rows(driver):
    """
    Find chat rows that contain unread indicators.
    More reliable than targeting only unread badges.
    """
    rows = []

    possible_row_selectors = [
        "div[role='listitem']",
        "div[role='row']"
    ]

    for row_selector in possible_row_selectors:
        try:
            candidates = driver.find_elements(By.CSS_SELECTOR, row_selector)

            for row in candidates:
                try:
                    text = (row.text or "").lower()
                    aria = (row.get_attribute("aria-label") or "").lower()
                    html = (row.get_attribute("innerHTML") or "").lower()

                    if "unread" in text or "unread" in aria or "unread" in html:
                        rows.append(row)
                        continue

                    badge_selectors = [
                        "span[aria-label*='unread']",
                        "div[aria-label*='unread']",
                        "span[data-testid*='icon-unread']"
                    ]

                    found_badge = False
                    for badge_selector in badge_selectors:
                        badges = row.find_elements(By.CSS_SELECTOR, badge_selector)
                        if badges:
                            found_badge = True
                            break

                    if found_badge:
                        rows.append(row)

                except Exception:
                    continue

            if rows:
                return rows

        except Exception:
            continue

    return rows


def get_chat_name_from_row(row):
    """Extract chat name from a chat row"""
    selectors = [
        "span[title]",
        "div[title]",
        "._ak8q span[dir='auto']"
    ]

    for selector in selectors:
        try:
            elems = row.find_elements(By.CSS_SELECTOR, selector)
            for elem in elems:
                title = elem.get_attribute("title")
                text = (elem.text or "").strip()

                if title and title.strip():
                    return title.strip()
                if text:
                    return text
        except Exception:
            continue

    return None


def get_unread_count_from_row(row):
    """Extract unread count from a row"""
    try:
        possible_elements = row.find_elements(By.CSS_SELECTOR, "span, div")
        for elem in possible_elements:
            try:
                txt = (elem.text or "").strip()
                if txt.isdigit():
                    value = int(txt)
                    if 1 <= value <= 999:
                        return value
            except Exception:
                continue
    except Exception:
        pass

    return 1


def open_chat_row(driver, row):
    """Open a chat row reliably"""
    try:
        driver.execute_script("arguments[0].scrollIntoView({block: 'center'});", row)
        time.sleep(0.5)

        try:
            row.click()
        except Exception:
            driver.execute_script("arguments[0].click();", row)

        time.sleep(1.5)
        return True

    except Exception as e:
        print(f"open_chat_row error: {e}")
        return False


def get_current_chat_name(driver):
    """Get the name of the currently open chat from the header"""
    selectors = [
        "header span[title]",
        "div[data-testid='conversation-title'] span[title]",
        "header div[title]"
    ]

    for selector in selectors:
        try:
            elem = driver.find_element(By.CSS_SELECTOR, selector)
            name = elem.get_attribute("title") or elem.text
            if name and name.strip():
                return name.strip()
        except Exception:
            continue

    return None


def extract_message_text(message_element):
    """Extract text from a message element safely"""
    try:
        text_spans = message_element.find_elements(
            By.CSS_SELECTOR,
            "span[data-testid='selectable-text']"
        )

        for span in text_spans:
            try:
                text = span.text
                if text and text.strip():
                    text = text.strip()
                    text = re.sub(r'\d+:\d+\s*(?:am|pm)', '', text, flags=re.IGNORECASE).strip()
                    text = re.sub(r'Read more$', '', text, flags=re.IGNORECASE).strip()
                    text = ' '.join(text.split())
                    if text:
                        return text
            except Exception:
                continue

        try:
            text = message_element.text
            if text:
                lines = text.split('\n')
                clean_lines = []
                for line in lines:
                    if not re.match(r'\d+:\d+\s*(?:am|pm)', line, flags=re.IGNORECASE) and "Read more" not in line:
                        clean_lines.append(line.strip())
                result = ' '.join(clean_lines).strip()
                if result:
                    return result
        except Exception:
            pass

    except Exception:
        pass

    return None


def read_and_reply_messages(driver, router, state, chat_name, unread_count, processed_messages):
    """Read messages from current chat and reply"""
    try:
        time.sleep(2)

        message_elements = driver.find_elements(
            By.CSS_SELECTOR,
            "div.copyable-text[data-pre-plain-text], div.message-in, div.message-out"
        )

        if not message_elements:
            print("No message elements found")
            return False

        incoming_messages = []

        for msg in message_elements:
            try:
                pre_plain = msg.get_attribute("data-pre-plain-text") or ""

                match = re.search(r'\] (.*?):', pre_plain)
                if match:
                    sender = match.group(1).strip()

                    if "you" in sender.lower():
                        continue

                    text = extract_message_text(msg)
                    if text and len(text) > 0:
                        if any(skip in text for skip in [
                            "Thank you for your message",
                            "How can I help you",
                            "Reply with 'menu'",
                            "You selected:"
                        ]):
                            continue

                        incoming_messages.append((msg, text, sender))
            except Exception:
                continue

        new_messages = incoming_messages[-unread_count:] if incoming_messages else []

        for msg, text, sender in new_messages:
            msg_id = f"{chat_name}|{sender}|{text}"

            if msg_id not in processed_messages:
                processed_messages.add(msg_id)
                print(f"\n📨 Message: {text[:100]}")

                reply = router.route(chat_name, text)

                if reply:
                    print(f"🤖 Reply: {reply[:100]}...")
                    if send_reply(driver, reply):
                        print("✅ Reply sent!")
                    else:
                        print("❌ Failed to send reply")
                else:
                    print("No reply generated")

        return True

    except Exception as e:
        print(f"Error in read_and_reply_messages: {e}")
        return False


def send_reply(driver, reply_text):
    """Send a reply instantly without character-by-character typing"""
    try:
        selectors = [
            "div[contenteditable='true'][data-tab='10']",
            "div[contenteditable='true'][role='textbox']",
            "div[data-testid='conversation-compose-box'] div[contenteditable='true']",
            "footer div[contenteditable='true']"
        ]

        input_box = None
        for selector in selectors:
            try:
                input_box = WebDriverWait(driver, 5).until(
                    EC.element_to_be_clickable((By.CSS_SELECTOR, selector))
                )
                print(f"Found input box with selector: {selector}")
                break
            except TimeoutException:
                continue
            except Exception:
                continue

        if not input_box:
            print("Could not find input box")
            return False

        driver.execute_script("""
            const el = arguments[0];
            const text = arguments[1];

            el.focus();
            el.innerHTML = '';
            el.textContent = text;
            el.dispatchEvent(new Event('input', { bubbles: true }));
            el.dispatchEvent(new Event('change', { bubbles: true }));
        """, input_box, reply_text)

        time.sleep(0.2)
        input_box.send_keys(Keys.ENTER)
        return True

    except Exception as e:
        print(f"Error sending reply: {e}")
        return False