import json
import os
from datetime import datetime
from config import (
    USERS_JSON, LEADS_JSON, MESSAGES_JSON, 
    LOGS_JSON, DATA_FOLDER
)

class StateManager:
    """
    Handles reading/writing messages, leads, logs AND user conversation states
    """
    def __init__(self):
        # Ensure data folder exists
        os.makedirs(DATA_FOLDER, exist_ok=True)
        
        # File paths from config
        self.users_file = USERS_JSON
        self.leads_file = LEADS_JSON
        self.messages_file = MESSAGES_JSON
        self.logs_file = LOGS_JSON
        
        # In-memory user states for conversation flow
        self.user_states = {}
        
        print(f"StateManager initialized - Data folder: {DATA_FOLDER}")

    # ========== FILE OPERATIONS ==========
    def load_json(self, path):
        try:
            with open(path, "r", encoding="utf-8") as f:
                return json.load(f)
        except (FileNotFoundError, json.JSONDecodeError):
            return {}

    def save_json(self, path, data):
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)

    # ========== CONVERSATION STATE MANAGEMENT ==========
    def get_user_state(self, phone):
        """
        Get user conversation state, create if doesn't exist
        """
        if phone not in self.user_states:
            self.user_states[phone] = {}  # Empty state
        return self.user_states[phone]

    def set_user_state(self, phone, state):
        """
        Set user conversation state
        """
        self.user_states[phone] = state
        print(f"Updated state for {phone}: {state}")

    def clear_user_state(self, phone):
        """
        Clear user conversation state
        """
        if phone in self.user_states:
            del self.user_states[phone]
            print(f"Cleared state for {phone}")

    # ========== MESSAGE LOGGING ==========
    def log_message(self, phone, msg, outgoing=False):
        """
        Log message to JSON file
        """
        logs = self.load_json(self.logs_file)
        if phone not in logs:
            logs[phone] = []
        
        logs[phone].append({
            "message": msg,
            "outgoing": outgoing,
            "timestamp": datetime.now().isoformat()
        })
        self.save_json(self.logs_file, logs)

    def save_message(self, phone, msg, incoming=True):
        """
        Save message to messages.json (compatibility with existing code)
        """
        messages = self.load_json(self.messages_file)
        if phone not in messages:
            messages[phone] = []
        
        messages[phone].append({
            "text": msg,
            "incoming": incoming,
            "timestamp": datetime.now().isoformat()
        })
        self.save_json(self.messages_file, messages)
        
        # Also log to logs.json
        self.log_message(phone, msg, outgoing=not incoming)

    # ========== LEAD MANAGEMENT ==========
    def save_lead(self, phone, name, service, details=None):
        """
        Save lead information
        """
        leads = self.load_json(self.leads_file)
        lead_data = {
            "phone": phone,
            "name": name,
            "service": service,
            "details": details or {},
            "timestamp": datetime.now().isoformat()
        }
        
        if phone not in leads:
            leads[phone] = []
        
        leads[phone].append(lead_data)
        self.save_json(self.leads_file, leads)
        print(f"Lead saved for {phone}: {service}")

    # ========== USER MANAGEMENT ==========
    def get_user(self, phone):
        """
        Get user info
        """
        users = self.load_json(self.users_file)
        return users.get(phone)

    def save_user(self, phone, user_data):
        """
        Save user info
        """
        users = self.load_json(self.users_file)
        users[phone] = user_data
        self.save_json(self.users_file, users)

    def get_conversation_history(self, phone, limit=10):
        """
        Get recent conversation history for a user
        """
        messages = self.load_json(self.messages_file)
        user_messages = messages.get(phone, [])
        return user_messages[-limit:] if user_messages else []