# bot/watcher.py
import time
import re
import random
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import StaleElementReferenceException, NoSuchElementException

def watch_messages(driver, router, state):
    print("=" * 50)
    print("WHATSAPP MESSAGE WATCHER STARTED")
    print("=" * 50)
    
    # Wait for WhatsApp to load
    print("Waiting for WhatsApp to load...")
    time.sleep(8)
    print("WhatsApp loaded. Monitoring for messages...")
    
    processed_messages = set()
    processed_chats = set()
    
    while True:
        try:
            # Find all unread indicators
            unread_indicators = driver.find_elements(By.CSS_SELECTOR, "span[aria-label*='unread']")
            
            if not unread_indicators:
                processed_chats.clear()
                time.sleep(2)
                continue
            
            print(f"\n📬 Found {len(unread_indicators)} chat(s) with unread messages")
            
            for indicator in unread_indicators:
                try:
                    # Get unread count
                    try:
                        count_span = indicator.find_element(By.CSS_SELECTOR, "span")
                        unread_count = int(count_span.text)
                    except:
                        unread_count = 1
                    
                    # Find the chat element
                    chat = None
                    chat_name = None
                    
                    # Try to find the chat element
                    try:
                        chat = indicator.find_element(By.XPATH, "./ancestor::div[@role='row']")
                    except:
                        try:
                            parent = indicator
                            for _ in range(6):
                                parent = parent.find_element(By.XPATH, "..")
                                if parent.get_attribute("role") == "row":
                                    chat = parent
                                    break
                        except:
                            pass
                    
                    if chat:
                        # Get chat name
                        try:
                            name_elem = chat.find_element(By.CSS_SELECTOR, "span[title]")
                            chat_name = name_elem.get_attribute("title")
                        except:
                            pass
                    
                    if not chat_name:
                        chat_name = "Unknown"
                    
                    # Skip if already processed
                    if chat_name in processed_chats:
                        print(f"Skipping {chat_name} - already processed")
                        continue
                    
                    print(f"\n{'='*60}")
                    print(f"💬 Processing {chat_name} - {unread_count} new message(s)")
                    print(f"{'='*60}")
                    
                    # Click to open chat - optimized speed
                    if chat:
                        try:
                            chat.click()
                            time.sleep(0.5)  # Reduced from 2 seconds
                            processed_chats.add(chat_name)
                        except:
                            print("Failed to click chat")
                            continue
                    else:
                        print("Could not find chat element")
                        continue
                    
                    # Read and reply to messages
                    read_and_reply_messages(driver, router, state, chat_name, unread_count, processed_messages)
                    
                    time.sleep(1)  # Reduced from 2 seconds
                    
                except StaleElementReferenceException:
                    print("Stale element, continuing...")
                    continue
                except Exception as e:
                    print(f"Error processing indicator: {e}")
                    continue
            
            processed_chats.clear()
            time.sleep(2)  # Reduced from 3 seconds
            
        except Exception as e:
            print(f"Watcher error: {e}")
            time.sleep(5)

def get_current_chat_name(driver):
    """Get the name of the currently open chat from the header"""
    try:
        selectors = [
            "header span[title]",
            "div[data-testid='conversation-title'] span[title]",
            "header div[title]"
        ]
        
        for selector in selectors:
            try:
                elem = driver.find_element(By.CSS_SELECTOR, selector)
                name = elem.get_attribute("title") or elem.text
                if name and name.strip():
                    return name.strip()
            except:
                continue
    except:
        pass
    
    return None

def extract_message_text(message_element):
    """Extract text from a message element safely"""
    try:
        # Try to get text from selectable-text span
        text_spans = message_element.find_elements(By.CSS_SELECTOR, "span[data-testid='selectable-text']")
        
        for span in text_spans:
            try:
                text = span.text
                if text and text.strip():
                    text = text.strip()
                    # Remove timestamp
                    text = re.sub(r'\d+:\d+\s*(?:am|pm)', '', text).strip()
                    # Remove "Read more"
                    text = re.sub(r'Read more$', '', text).strip()
                    # Clean up whitespace
                    text = ' '.join(text.split())
                    if text:
                        return text
            except:
                continue
        
        # Alternative: get direct text
        try:
            text = message_element.text
            if text:
                lines = text.split('\n')
                clean_lines = []
                for line in lines:
                    if not re.match(r'\d+:\d+\s*(?:am|pm)', line) and "Read more" not in line:
                        clean_lines.append(line.strip())
                result = ' '.join(clean_lines).strip()
                if result:
                    return result
        except:
            pass
            
    except Exception as e:
        pass
    
    return None

def read_and_reply_messages(driver, router, state, chat_name, unread_count, processed_messages):
    """Read messages from current chat and reply - optimized for speed"""
    try:
        # Reduced wait time for messages to load
        time.sleep(0.5)  # Reduced from 2 seconds
        
        # Find all message elements
        message_elements = driver.find_elements(By.CSS_SELECTOR, "div.copyable-text[data-pre-plain-text]")
        
        if not message_elements:
            print("No message elements found")
            return False
        
        # Filter for incoming messages
        incoming_messages = []
        
        for msg in message_elements:
            try:
                pre_plain = msg.get_attribute("data-pre-plain-text") or ""
                
                match = re.search(r'\] (.*?):', pre_plain)
                if match:
                    sender = match.group(1).strip()
                    
                    # Skip messages sent by us
                    if "You" in sender or "you" in sender.lower():
                        continue
                    
                    text = extract_message_text(msg)
                    if text and len(text) > 0:
                        # Skip bot's own responses
                        if any(skip in text for skip in ["Thank you for your message", "How can I help you", "Reply with 'menu'", "You selected:"]):
                            continue
                        
                        incoming_messages.append((msg, text, sender))
            except:
                continue
        
        # Get only new messages
        new_messages = incoming_messages[-unread_count:] if incoming_messages else []
        
        for msg, text, sender in new_messages:
            msg_id = f"{chat_name}_{text}_{time.time()}"
            
            if msg_id not in processed_messages:
                processed_messages.add(msg_id)
                print(f"\n📨 Message: {text[:100]}")
                
                # Process through router
                reply = router.route(chat_name, text)
                
                if reply:
                    print(f"🤖 Reply: {reply[:100]}...")
                    
                    # Send reply instantly
                    if send_reply_instant(driver, reply):
                        print("✅ Reply sent!")
                    else:
                        print("❌ Failed to send reply")
                else:
                    print("No reply generated")
        
        return True
        
    except Exception as e:
        print(f"Error in read_and_reply_messages: {e}")
        return False

def send_reply_instant(driver, reply_text):
    """Send a reply instantly - optimized for speed (no character-by-character typing)"""
    try:
        # Find input box quickly
        input_box = None
        selectors = [
            "div[contenteditable='true'][data-tab='10']",
            "div[contenteditable='true'][role='textbox']",
            "div[data-testid='conversation-compose-box'] div[contenteditable='true']",
            "footer div[contenteditable='true']"
        ]
        
        for selector in selectors:
            try:
                input_box = driver.find_element(By.CSS_SELECTOR, selector)
                if input_box and input_box.is_enabled():
                    break
            except:
                continue
        
        if not input_box:
            # Try with WebDriverWait for the last attempt
            try:
                input_box = WebDriverWait(driver, 2).until(
                    EC.element_to_be_clickable((By.CSS_SELECTOR, "div[contenteditable='true']"))
                )
            except:
                print("Could not find input box")
                return False
        
        # Click and focus
        input_box.click()
        time.sleep(0.1)
        
        # Clear input box using JavaScript
        driver.execute_script("""
            arguments[0].focus();
            arguments[0].innerHTML = '';
            arguments[0].innerText = '';
            arguments[0].dispatchEvent(new Event('input', {bubbles: true}));
        """, input_box)
        
        # Paste entire message at once using JavaScript (no character delays)
        driver.execute_script("""
            arguments[0].innerText = arguments[1];
            arguments[0].dispatchEvent(new Event('input', {bubbles: true}));
        """, input_box, reply_text)
        
        # Tiny pause for WhatsApp to register
        time.sleep(0.1)
        
        # Send using Enter key
        input_box.send_keys(Keys.ENTER)
        
        return True
        
    except Exception as e:
        print(f"Send error: {e}")
        return False

# Keep the original function name for compatibility
send_reply = send_reply_instant