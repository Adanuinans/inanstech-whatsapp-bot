# engine/menus.py
class MenuEngine:
    """
    Handles structured menu options for the bot
    """
    def __init__(self, state):
        self.state = state
        self.menu_options = {
            "1": "Website Design",
            "2": "Mobile App Development",
            "3": "Software Development",
            "4": "Digital Marketing",
            "5": "E-commerce Solutions",
            "6": "Branding & Design",
            "7": "Pricing / Packages",
            "8": "Portfolio",
            "9": "Talk to an Agent"
        }

    def get_reply(self, phone, message):
        """
        Returns reply based on menu selection
        """
        print(f"MenuEngine processing message: {message} from {phone}")
        
        # Get user state
        user_state = self.state.get_user_state(phone)
        print(f"Current user state: {user_state}")
        
        # Check if user wants to see menu
        if message.lower() in ["menu", "help", "start"]:
            user_state["stage"] = "menu"
            self.state.set_user_state(phone, user_state)
            return self.show_menu()
        
        # If user is in menu stage
        if user_state.get("stage") == "menu":
            if message in self.menu_options:
                user_state["selected_service"] = self.menu_options[message]
                user_state["stage"] = "lead_capture"
                self.state.set_user_state(phone, user_state)
                
                # Save lead information
                self.state.save_lead(phone, "User", self.menu_options[message])
                
                return f"You selected: {self.menu_options[message]}. Please provide your name and contact details so we can reach out to you."
            else:
                return "Please choose a valid option (1-9)."
        
        # Check if user is in lead capture stage
        if user_state.get("stage") == "lead_capture":
            # Save lead details
            user_state["lead_details"] = message
            user_state["stage"] = "completed"
            self.state.set_user_state(phone, user_state)
            
            # Update lead with details
            self.state.save_lead(phone, message, user_state.get("selected_service", "Unknown"), {"details": message})
            
            return f"Thank you for your interest! We'll contact you shortly regarding {user_state.get('selected_service')}. A representative will reach out within 24 hours."
        
        # First time - don't show menu automatically, just return None
        # This allows FAQ to handle first messages
        if "stage" not in user_state:
            # Don't set stage here - let FAQ handle it first
            return None
        
        return None
    
    def show_menu(self):
        """Display main menu"""
        menu_text = "📋 *Main Menu*\n\n"
        for key, val in self.menu_options.items():
            menu_text += f"{key}. {val}\n"
        menu_text += "\nReply with the number of your choice."
        return menu_text